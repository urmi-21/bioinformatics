/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cs567.hw4;

/**
 *
 * @author usingh
 */
public class ExampleInput {

    /*
	 * For l = 8, The median string is TGACGATT
	 * and the motif is [2,5,1,2,4,5,8]
     */
    public static String INPUT1 = "ATTGACGATTGACT" + "\n"
            + "GAACTTGACGATTGCAG" + "\n"
            + "GTGACGATTTACCGACT" + "\n"
            + "CATGACGATTGGAC" + "\n"
            + "GGACTGACGATTAT" + "\n"
            + "GATCTTGACGATTCTAT" + "\n"
            + "CATAGATATGACGATTA";
}
